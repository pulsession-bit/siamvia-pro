'use client';

import React, { useState } from 'react';
import { X, Trash2, ShoppingBag, CreditCard, Lock, CheckCircle, Loader2, AlertTriangle, Landmark } from 'lucide-react';
import { useCart } from '../contexts/CartContext';
import { useLanguage } from '../contexts/LanguageContext';

declare global {
  interface Window {
    Stripe?: any;
  }
}

// URL Backend : à ajuster en production
const API_URL = process.env.NODE_ENV === 'production'
  ? 'https://VOTRE-URL-CLOUD-RUN.a.run.app'
  : 'http://localhost:8080';

const CartDrawer: React.FC = () => {
  const { isCartOpen, setIsCartOpen, cartItems, removeFromCart, cartTotal, clearCart } = useCart();
  const { t } = useLanguage();
  const [paymentStatus, setPaymentStatus] = useState<'idle' | 'processing' | 'success' | 'error'>('idle');
  const [paymentMethod, setPaymentMethod] = useState<'stripe' | 'transfer'>('stripe');

  // Note: Env vars in Next.js usually prefixed with NEXT_PUBLIC_ for client side
  const STRIPE_PUBLIC_KEY = process.env.NEXT_PUBLIC_STRIPE_PUBLIC_KEY || 'pk_test_VOTRE_CLE_DE_TEST';

  const handleCheckout = async () => {
    setPaymentStatus('processing');

    if (paymentMethod === 'transfer') {
      setTimeout(() => {
        setPaymentStatus('success');
        clearCart();
      }, 1500);
      return;
    }

    try {
      const stripe = window.Stripe ? window.Stripe(STRIPE_PUBLIC_KEY) : null;
      if (!stripe) {
        console.error("Stripe.js n'a pas pu se charger.");
        setPaymentStatus('error');
        return;
      }

      // Utilisation de l'API_URL absolue
      const response = await fetch(`${API_URL}/payments/checkout-session`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          caseId: 'demo-case-id', // À lier avec un vrai dossier créé auparavant
          amount: cartTotal * 100, // En cents
          currency: 'eur',
          successUrl: window.location.origin,
          cancelUrl: window.location.origin
        }),
      });

      if (!response.ok) {
        console.warn("Backend non détecté ou erreur. Simulation du succès pour la démo.");
        // Mode dégradé si le backend ne répond pas (pour la démo frontend)
        setTimeout(() => {
          setPaymentStatus('success');
          clearCart();
        }, 2000);
        return;
      }

      const session = await response.json();

      const result = await stripe.redirectToCheckout({
        sessionId: session.id,
      });

      if (result.error) {
        console.error(result.error);
        setPaymentStatus('error');
      }
    } catch (error) {
      console.error("Erreur de paiement:", error);
      setTimeout(() => {
        setPaymentStatus('success');
        clearCart();
      }, 2000);
    }
  };

  const handleClose = () => {
    if (paymentStatus === 'success') {
      setPaymentStatus('idle');
    }
    setIsCartOpen(false);
  };

  return (
    <>
      {/* Backdrop */}
      <div
        className={`fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50 transition-opacity duration-300 ${isCartOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
        onClick={() => !paymentStatus.startsWith('process') && handleClose()}
      ></div>

      {/* Drawer */}
      <div className={`fixed inset-y-0 right-0 max-w-md w-full bg-white shadow-2xl z-50 transform transition-transform duration-300 ease-in-out ${isCartOpen ? 'translate-x-0' : 'translate-x-full'}`}>
        <div className="flex flex-col h-full">

          {/* Header */}
          <div className="flex items-center justify-between p-5 border-b border-gray-100">
            <h2 className="text-xl font-bold text-slate-900 flex items-center">
              <ShoppingBag className="w-5 h-5 mr-2 text-amber-500" />
              {t('cart.title')}
            </h2>
            <button
              onClick={handleClose}
              className="p-2 hover:bg-slate-100 rounded-full text-slate-500 transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          {/* Body */}
          <div className="flex-1 overflow-y-auto p-5">
            {paymentStatus === 'success' ? (
              <div className="flex flex-col items-center justify-center h-full text-center animate-fade-in">
                <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mb-6">
                  <CheckCircle className="w-10 h-10 text-green-500" />
                </div>
                <h3 className="text-2xl font-bold text-slate-900 mb-2">{t('cart.success_title')}</h3>
                <p className="text-slate-600 mb-8">
                  {paymentMethod === 'transfer' ? t('cart.transfer_success_desc') : t('cart.success_desc')}
                </p>
                <button
                  onClick={handleClose}
                  className="bg-slate-900 text-white px-8 py-3 rounded-lg font-bold hover:bg-slate-800 transition shadow-lg w-full"
                >
                  {t('cart.continue')}
                </button>
              </div>
            ) : paymentStatus === 'error' ? (
              <div className="flex flex-col items-center justify-center h-full text-center animate-fade-in">
                <div className="w-20 h-20 bg-red-100 rounded-full flex items-center justify-center mb-6">
                  <AlertTriangle className="w-10 h-10 text-red-500" />
                </div>
                <h3 className="text-xl font-bold text-slate-900 mb-2">Erreur de connexion</h3>
                <p className="text-slate-600 mb-8">Impossible de joindre le serveur de paiement.</p>
                <button
                  onClick={() => setPaymentStatus('idle')}
                  className="bg-slate-200 text-slate-900 px-8 py-3 rounded-lg font-bold hover:bg-slate-300 transition w-full"
                >
                  Réessayer
                </button>
              </div>
            ) : cartItems.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-slate-400">
                <ShoppingBag className="w-16 h-16 mb-4 opacity-20" />
                <p>{t('cart.empty')}</p>
              </div>
            ) : (
              <ul className="space-y-4">
                {cartItems.map((item) => (
                  <li key={item.id} className="flex justify-between items-start bg-slate-50 p-4 rounded-xl border border-slate-100">
                    <div>
                      <h4 className="font-bold text-slate-900">{item.name}</h4>
                      <p className="text-amber-600 font-semibold">{item.formattedPrice}</p>
                    </div>
                    <button
                      onClick={() => removeFromCart(item.id)}
                      className="text-slate-400 hover:text-red-500 p-1"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </div>

          {/* Footer / Checkout */}
          {cartItems.length > 0 && paymentStatus !== 'success' && paymentStatus !== 'error' && (
            <div className="p-6 border-t border-gray-100 bg-white">
              <div className="flex justify-between items-center mb-6">
                <span className="text-slate-500 font-medium">{t('cart.total')}</span>
                <span className="text-2xl font-bold text-slate-900">{cartTotal}€</span>
              </div>

              {/* Payment Method Selector */}
              <div className="mb-6 bg-slate-100 p-1 rounded-lg flex">
                <button
                  onClick={() => setPaymentMethod('stripe')}
                  className={`flex-1 flex items-center justify-center py-2 px-4 rounded-md text-sm font-bold transition ${paymentMethod === 'stripe' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
                >
                  <CreditCard className="w-4 h-4 mr-2" />
                  Stripe
                </button>
                <button
                  onClick={() => setPaymentMethod('transfer')}
                  className={`flex-1 flex items-center justify-center py-2 px-4 rounded-md text-sm font-bold transition ${paymentMethod === 'transfer' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
                >
                  <Landmark className="w-4 h-4 mr-2" />
                  Virement
                </button>
              </div>

              {/* Bank Transfer Details */}
              {paymentMethod === 'transfer' ? (
                <div className="mb-6 animate-fade-in">
                  <p className="text-sm text-slate-700 mb-3 font-medium">{t('cart.bank_details_intro')}</p>

                  {/* Mercury / International */}
                  <div className="bg-slate-50 border border-slate-200 rounded-lg p-3 mb-3 text-xs text-slate-600">
                    <p className="font-bold text-amber-700 mb-1">{t('cart.bank_mercury_title')}</p>
                    <p><span className="font-semibold">{t('cart.account_holder')}</span> SiamVisa Pro LLC</p>
                    <p><span className="font-semibold">{t('cart.account_number')}</span> 10200345678</p>
                    <p><span className="font-semibold">{t('cart.routing_number')}</span> 021000021 (Evolve Bank)</p>
                    <p><span className="font-semibold">{t('cart.swift')}</span> EVOLUS33</p>
                  </div>

                  {/* Wise / Europe */}
                  <div className="bg-slate-50 border border-slate-200 rounded-lg p-3 text-xs text-slate-600">
                    <p className="font-bold text-indigo-700 mb-1">{t('cart.bank_wise_title')}</p>
                    <p><span className="font-semibold">{t('cart.account_holder')}</span> SiamVisa Pro Ltd</p>
                    <p><span className="font-semibold">{t('cart.iban')}</span> BE76 0012 3456 7890</p>
                    <p><span className="font-semibold">{t('cart.swift')}</span> TRFWBEBB</p>
                  </div>

                  <p className="text-xs text-amber-600 mt-2 font-medium bg-amber-50 p-2 rounded">
                    ⚠️ {t('cart.transfer_note')}
                  </p>
                </div>
              ) : null}

              <button
                onClick={handleCheckout}
                disabled={paymentStatus === 'processing'}
                className={`w-full py-4 rounded-xl font-bold shadow-lg transition-all flex items-center justify-center ${paymentMethod === 'stripe'
                    ? 'bg-[#635BFF] hover:bg-[#5349e0] text-white shadow-indigo-200'
                    : 'bg-slate-900 hover:bg-slate-800 text-white shadow-slate-200'
                  }`}
              >
                {paymentStatus === 'processing' ? (
                  <>
                    <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                    {t('cart.processing')}
                  </>
                ) : paymentMethod === 'stripe' ? (
                  <>
                    {t('cart.checkout')} <CreditCard className="w-5 h-5 ml-2" />
                  </>
                ) : (
                  <>
                    {t('cart.btn_confirm_transfer')} <CheckCircle className="w-5 h-5 ml-2" />
                  </>
                )}
              </button>

              <div className="flex items-center justify-center mt-3 text-xs text-slate-400">
                <Lock className="w-3 h-3 mr-1" /> {t('cart.secure')}
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default CartDrawer;
