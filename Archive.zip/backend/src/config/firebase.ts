
import admin from "firebase-admin";
import dotenv from "dotenv";
import fs from "fs";
import path from "path";

dotenv.config();

if (!admin.apps.length) {
  try {
    const serviceAccountPath = path.resolve("service-account.json");

    // 0. Priorité Absolue : Fichier service-account.json à la racine du backend
    if (fs.existsSync(serviceAccountPath)) {
      console.log("Initializing Firebase with service-account.json...");
      const serviceAccount = JSON.parse(fs.readFileSync(serviceAccountPath, "utf8"));
      
      admin.initializeApp({
        credential: admin.credential.cert(serviceAccount),
      });
      console.log("✅ Firebase initialized successfully via service-account.json.");
    }
    // 1. Fallback : Variables d'environnement explicites (Local ou Serveur sans IAM)
    else if (
      process.env.FIREBASE_PROJECT_ID &&
      process.env.FIREBASE_CLIENT_EMAIL &&
      process.env.FIREBASE_PRIVATE_KEY
    ) {
      console.log("Initializing Firebase with .env variables...");
      
      // Nettoyage critique de la clé privée pour gérer les sauts de ligne (\n)
      const privateKey = process.env.FIREBASE_PRIVATE_KEY.replace(/\\n/g, "\n");

      admin.initializeApp({
        credential: admin.credential.cert({
          projectId: process.env.FIREBASE_PROJECT_ID,
          clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
          privateKey: privateKey,
        }),
      });
      console.log("✅ Firebase initialized successfully via Credentials env vars.");
    } 
    // 2. Fallback : Google Cloud Default Credentials (pour Cloud Run en production)
    else if (process.env.GOOGLE_APPLICATION_CREDENTIALS) {
      console.log("Initializing Firebase with Google Application Credentials...");
      admin.initializeApp();
      console.log("✅ Firebase initialized successfully via GOOGLE_APPLICATION_CREDENTIALS.");
    } 
    else {
       // Mode Mock/Dev si aucune clé n'est fournie OU SI ON EST SUR CLOUD RUN SANS CONFIG
       // C'est CRUCIAL pour éviter que le conteneur ne crash (Revision Failed)
       console.warn("⚠️ NO FIREBASE CREDENTIALS FOUND. Initializing Default App to prevent crash.");
       admin.initializeApp({ projectId: "demo-project" });
    }
  } catch (error) {
    console.error("❌ Firebase initialization failed:", error);
    // Tenter une initialisation bidon pour ne pas casser l'export 'db'
    if (!admin.apps.length) {
        try { admin.initializeApp({ projectId: "fallback-error-mode" }); } catch(e) {}
    }
  }
}

export const db = admin.firestore();
export const firestoreAdmin = admin;
