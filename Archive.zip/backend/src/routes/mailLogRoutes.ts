import { Router, Request, Response } from "express";
import { db } from "../config/firebase";
import { authMiddleware, requireRoles, AuthRequest } from "../middleware/auth";
import { MailLogEntry } from "../types/models";

const router = Router();

/**
 * GET /mail-logs
 * Query params:
 *   - limit (default 50)
 *   - type (optional)
 *   - status (SENT|FAILED, optional)
 */
router.get(
  "/",
  authMiddleware,
  requireRoles("ADMIN", "SUPER_ADMIN"),
  async (req: AuthRequest, res: Response) => {
    try {
      const { limit = "50", type, status } = (req as any).query;

      // Use inference or cast to any if Type definitions are strict
      let query: any = db
        .collection("mailLogs")
        .orderBy("createdAt", "desc")
        .limit(Math.min(Number(limit) || 50, 100));

      if (type && typeof type === "string") {
        query = query.where("type", "==", type);
      }

      if (status && typeof status === "string") {
        query = query.where("status", "==", status);
      }

      const snap = await query.get();

      const logs: MailLogEntry[] = snap.docs.map((doc: any) => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          createdAt: data.createdAt?.toDate?.() ?? new Date(),
        };
      });

      (res as any).json(logs);
    } catch (err) {
      console.error("Error GET /mail-logs :", err);
      (res as any).status(500).json({ error: "Server error" });
    }
  }
);

export default router;