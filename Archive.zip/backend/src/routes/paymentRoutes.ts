
import express, { Router } from "express";
import { stripe } from "../config/stripe";
import { db } from "../config/firebase";
import { AuthRequest, authMiddleware, requireRoles } from "../middleware/auth";
import { Payment } from "../types/models";
import { z } from "zod";
import Stripe from "stripe";

const router = Router();

const createCheckoutSchema = z.object({
  caseId: z.string(),
  amount: z.number().int().positive(), // en cents
  currency: z.string().default("eur"),
  successUrl: z.string().url(),
  cancelUrl: z.string().url(),
});

// Endpoint appelé par le Frontend pour générer le lien de paiement
router.post(
  "/checkout-session",
  // TODO: Pour un MVP, on laisse ouvert ou on sécurise si le client a un compte
  // authMiddleware, 
  async (req, res) => {
    try {
      const parse = createCheckoutSchema.safeParse(req.body);
      if (!parse.success) {
        return res.status(400).json({ error: "Invalid body" });
      }
      const { caseId, amount, currency, successUrl, cancelUrl } = parse.data;

      // Pour la démo, on n'échoue pas si le case n'existe pas, car on n'a peut-être pas encore syncé le front et le back
      // En prod : décommenter
      // const caseDoc = await db.collection("cases").doc(caseId).get();
      // if (!caseDoc.exists) return res.status(404).json({ error: "Case not found" });

      const session = await stripe.checkout.sessions.create({
        mode: "payment",
        payment_method_types: ["card"],
        line_items: [
          {
            price_data: {
              currency,
              unit_amount: amount,
              product_data: {
                name: "SiamVisa Pro – DTV Service Fee",
              },
            },
            quantity: 1,
          },
        ],
        success_url: successUrl,
        cancel_url: cancelUrl,
        metadata: { caseId },
      });

      const now = new Date();
      // On enregistre l'intention de paiement
      const paymentRef = await db.collection("payments").add({
        caseId,
        amount,
        currency,
        provider: "STRIPE",
        stripeSessionId: session.id,
        status: "PENDING",
        createdAt: now,
      });

      const payment: Payment = {
        id: paymentRef.id,
        caseId,
        amount,
        currency,
        provider: "STRIPE",
        stripeSessionId: session.id,
        status: "PENDING",
        createdAt: now,
      };

      res.json({ checkoutUrl: session.url, payment });
    } catch (err: any) {
      console.error("Create checkout error", err);
      res.status(500).json({ error: err.message || "Server error" });
    }
  }
);

// Webhook Stripe (à configurer dans Stripe Dashboard : /payments/webhook)
router.post(
  "/webhook",
  // Cast express.raw middleware to any to fix overload mismatch error with RequestHandler
  express.raw({ type: "application/json" }) as any,
  async (req, res) => {
    const sig = req.headers["stripe-signature"];
    if (!sig || typeof sig !== "string") {
      return res.status(400).send("Missing signature");
    }
    
    // Si pas de secret configuré, on ne peut pas valider
    if (!process.env.STRIPE_WEBHOOK_SECRET) {
      console.error("STRIPE_WEBHOOK_SECRET not set");
      return res.status(500).send("Config error");
    }

    let event: Stripe.Event;
    try {
      event = stripe.webhooks.constructEvent(
        req.body,
        sig,
        process.env.STRIPE_WEBHOOK_SECRET
      );
    } catch (err: any) {
      console.error("Webhook signature error", err.message);
      return res.status(400).send(`Webhook Error: ${err.message}`);
    }

    try {
      if (event.type === "checkout.session.completed") {
        const session = event.data.object as any;
        const caseId = session.metadata?.caseId;
        const paymentIntentId = session.payment_intent as string;

        const snap = await db
          .collection("payments")
          .where("stripeSessionId", "==", session.id)
          .limit(1)
          .get();

        if (!snap.empty) {
          const doc = snap.docs[0];
          await doc.ref.update({
            status: "SUCCEEDED",
            stripePaymentIntentId: paymentIntentId,
            confirmedAt: new Date(),
          });

          // maj du dossier -> PAYMENT_CONFIRMED
          if (caseId) {
            // Optionnel : vérifier si case existe
            const caseRef = db.collection("cases").doc(caseId);
            await caseRef.update({
              status: "PAYMENT_CONFIRMED",
              updatedAt: new Date(),
            });
          }
        }
      }

      res.json({ received: true });
    } catch (err) {
      console.error("Webhook processing error", err);
      res.status(500).send("Webhook error");
    }
  }
);

export default router;
