
import { Router, Request, Response } from "express";
import { db } from "../config/firebase";
import { AuthRequest, authMiddleware, requireRoles } from "../middleware/auth";
import { VisaCase, CaseStatus, MailStatus } from "../types/models";
import { z } from "zod";
import sgMail from "@sendgrid/mail";
import { logMail } from "../services/mailLogService";

const router = Router();

// Configure SendGrid
if (process.env.SENDGRID_API_KEY) {
  sgMail.setApiKey(process.env.SENDGRID_API_KEY);
} else {
  console.warn("⚠️ SENDGRID_API_KEY is missing. Emails will not be sent.");
}

const TARGET_EMAIL = "pulssession@gmail.com";
const FROM_EMAIL = "contact@siamvisapro.com"; // Ensure this is a verified sender in SendGrid

// --- INTAKE ROUTE FOR ELIGIBILITY AGENT ---

const intakeSchema = z.object({
  fullName: z.string().optional(),
  email: z.string().email().optional().or(z.literal('')),
  phone: z.string().optional(),
  whatsapp: z.string().optional(),
  nationality: z.string(),
  countryOfResidence: z.string().optional(),
  visaType: z.string(),
  arrivalDate: z.string().optional(),
  duration: z.string().optional(),
  jobTitle: z.string().optional(),
  incomeSource: z.string().optional(),
  savingsAmount: z.number().optional(),
  currency: z.string().optional(),
  purpose: z.string().optional(),
  notes: z.string().optional(),
});

router.post("/intake", async (req: Request, res: Response) => {
  try {
      const parse = intakeSchema.safeParse((req as any).body);
      if (!parse.success) {
        (res as any).status(400).json({ error: "Invalid data", details: parse.error });
        return;
      }
      
      const data = parse.data;
      
      // Split name for JSON structure if provided
      let firstName = "Anonymous";
      let lastName = "User";
      if (data.fullName) {
        const nameParts = data.fullName.split(' ');
        lastName = nameParts.length > 1 ? nameParts.pop() || '' : '';
        firstName = nameParts.join(' ') || data.fullName;
      }

      // Determine Risk (Heuristic)
      let riskLevel = 'low';
      if (!data.savingsAmount || data.savingsAmount < 15000) riskLevel = 'medium'; 
      if (!data.incomeSource || data.incomeSource === 'other') riskLevel = 'medium';
      
      const intakeJson = {
          identity: {
              firstName,
              lastName,
              nationality: data.nationality
          },
          contact: {
              email: data.email || "Non fourni",
              phone: data.phone || "Non fourni",
              whatsapp: data.whatsapp || "Non fourni"
          },
          visaProject: {
              visaType: data.visaType,
              countryOfResidence: data.countryOfResidence || "Unknown",
              passportCountry: data.nationality,
              arrivalDatePlanned: data.arrivalDate || "unknown",
              stayDurationApprox: data.duration || "unknown",
              status: data.incomeSource || "unknown",
              savings: `${data.savingsAmount || 0} ${data.currency || 'EUR'}`
          },
          notes: data.notes || "",
          riskLevel
      };

      const emailBody = `
NOUVEAU FORMULAIRE D’ÉLIGIBILITÉ (ANONYME) – SIAMVISAPRO

1) Résumé
- Nom : ${data.fullName || "Anonyme"}
- Nationalité : ${data.nationality}
- Visa demandé : ${data.visaType}
- Arrivée prévue : ${data.arrivalDate || 'Inconnue'}
- Durée : ${data.duration || 'Inconnue'}
- Statut : ${data.incomeSource}
- Pays de résidence : ${data.countryOfResidence || 'Inconnu'}
- Épargne : ${data.savingsAmount} ${data.currency}

2) JSON
${JSON.stringify(intakeJson, null, 2)}

3) Niveau de risque
- Risque évalué : ${riskLevel}
      `;

      // Log for "Supervisor Agent" visibility in Cloud Run logs
      console.log("📨 --- PROCESSING INTAKE ---");
      console.log(`Target: ${TARGET_EMAIL}`);
      console.log(emailBody);

      // SendGrid Execution with Logging
      let emailStatus: MailStatus | "SKIPPED" = "FAILED";
      let logError: string | undefined;

      if (process.env.SENDGRID_API_KEY) {
        try {
          await sgMail.send({
            to: TARGET_EMAIL,
            from: FROM_EMAIL,
            subject: `Nouveau formulaire d’éligibilité – ${data.fullName || "Anonyme"}`,
            text: emailBody,
          });
          emailStatus = "SENT";
          console.log("✅ SendGrid: Email sent successfully.");
        } catch (sgError: any) {
          const detail = sgError?.response?.body || sgError?.message || String(sgError);
          console.error("❌ SendGrid Error:", detail);
          logError = typeof detail === "string" ? detail : JSON.stringify(detail);
          emailStatus = "FAILED";
        }
      } else {
        emailStatus = "SKIPPED";
        logError = "SENDGRID_API_KEY missing";
      }

      // 1. Log Mail
      await logMail({
        type: "INTAKE",
        to: TARGET_EMAIL,
        from: FROM_EMAIL,
        subject: `Nouveau formulaire d’éligibilité – ${data.fullName || "Anonyme"}`,
        status: emailStatus === "SKIPPED" ? "FAILED" : emailStatus,
        errorMessage: logError,
        meta: {
          clientId: data.email || "anonymous",
          visaType: data.visaType,
          riskLevel
        }
      });

      // 2. Save to Firestore 'intakes' collection
      await db.collection('intakes').add({
          ...intakeJson,
          originalData: data,
          emailStatus,
          createdAt: new Date()
      });

      (res as any).json({ success: true, riskLevel, emailStatus });

  } catch (err) {
      console.error("Intake error", err);
      (res as any).status(500).json({ error: "Server error" });
  }
});

// --- EXPERT APPOINTMENT ROUTE ---

const appointmentSchema = z.object({
  date: z.string(),
  slot1: z.string(),
  slot2: z.string(),
  contactMethod: z.string(),
  contactValue: z.string(),
  notes: z.string().optional(),
});

router.post("/appointment", async (req: Request, res: Response) => {
  try {
    const parse = appointmentSchema.safeParse((req as any).body);
    if (!parse.success) {
      (res as any).status(400).json({ error: "Invalid data", details: parse.error });
      return;
    }
    const data = parse.data;

    const emailBody = `
DEMANDE DE RENDEZ-VOUS EXPERT

- Date souhaitée : ${data.date}
- Option 1 : ${data.slot1}
- Option 2 : ${data.slot2}

- Méthode : ${data.contactMethod}
- Contact : ${data.contactValue}

- Notes : ${data.notes || "Aucune note"}
    `;

    // Log for Supervisor
    console.log("📅 --- PROCESSING APPOINTMENT ---");
    console.log(emailBody);

    // SendGrid Execution with Logging
    let emailStatus: MailStatus | "SKIPPED" = "FAILED";
    let logError: string | undefined;

    if (process.env.SENDGRID_API_KEY) {
      try {
        await sgMail.send({
          to: TARGET_EMAIL,
          from: FROM_EMAIL,
          subject: `Demande de RDV Expert – ${data.date}`,
          text: emailBody,
        });
        emailStatus = "SENT";
        console.log("✅ SendGrid: Appointment email sent successfully.");
      } catch (sgError: any) {
        const detail = sgError?.response?.body || sgError?.message || String(sgError);
        console.error("❌ SendGrid Error:", detail);
        logError = typeof detail === "string" ? detail : JSON.stringify(detail);
        emailStatus = "FAILED";
      }
    } else {
        emailStatus = "SKIPPED";
        logError = "SENDGRID_API_KEY missing";
    }

    // 1. Log Mail
    await logMail({
      type: "APPOINTMENT",
      to: TARGET_EMAIL,
      from: FROM_EMAIL,
      subject: `Demande de RDV Expert – ${data.date}`,
      status: emailStatus === "SKIPPED" ? "FAILED" : emailStatus,
      errorMessage: logError,
      meta: {
        date: data.date,
        method: data.contactMethod
      }
    });

    // 2. Save to Firestore 'appointments' collection
    await db.collection('appointments').add({
      ...data,
      status: 'PENDING',
      emailStatus,
      createdAt: new Date()
    });

    (res as any).json({ success: true, emailStatus });

  } catch (err) {
    console.error("Appointment error", err);
    (res as any).status(500).json({ error: "Server error" });
  }
});

// --- EXISTING ROUTES ---

const createCaseSchema = z.object({
  clientId: z.string(),
  visaType: z.string().default("DTV"),
});

const updateStatusSchema = z.object({
  status: z.string(),
});

const allowedStatuses: CaseStatus[] = [
  "LEAD_CREATED",
  "PRECHECK_IN_PROGRESS",
  "ELIGIBLE",
  "NOT_ELIGIBLE",
  "WAITING_PAYMENT",
  "PAYMENT_CONFIRMED",
  "DOCUMENTS_IN_PROGRESS",
  "CASE_COMPLETE",
  "SUBMITTED_TO_AUTHORITY",
  "PENDING_DECISION",
  "APPROVED",
  "REFUSED",
  "CANCELLED_CLIENT",
  "ABANDONED",
];

router.post(
  "/",
  authMiddleware,
  requireRoles("ADMIN", "AGENT", "SUPER_ADMIN", "PARTNER"),
  async (req: Request, res: Response) => {
    try {
      const parse = createCaseSchema.safeParse((req as any).body);
      if (!parse.success) {
        (res as any).status(400).json({ error: "Invalid body" });
        return;
      }
      const { clientId, visaType } = parse.data;
      const now = new Date();
      const reference = `DTV-${now.getTime()}-${Math.floor(
        Math.random() * 1000
      )}`;

      const docRef = await db.collection("cases").add({
        clientId,
        visaType,
        reference,
        status: "LEAD_CREATED",
        createdAt: now,
        updatedAt: now,
      });

      const visaCase: VisaCase = {
        id: docRef.id,
        clientId,
        visaType,
        reference,
        status: "LEAD_CREATED",
        createdAt: now,
        updatedAt: now,
      };

      (res as any).status(201).json(visaCase);
    } catch (err) {
      console.error("Create case error", err);
      (res as any).status(500).json({ error: "Server error" });
    }
  }
);

router.get(
  "/",
  authMiddleware,
  requireRoles("ADMIN", "AGENT", "SUPER_ADMIN", "ACCOUNTING", "PARTNER"),
  async (req: Request, res: Response) => {
    try {
      const { status, limit = "50" } = (req as any).query;
      const l = Math.min(parseInt(limit as string, 10) || 50, 200);

      // Use inference instead of explicit FirebaseFirestore.Query type which might be missing from namespace
      let query = db
        .collection("cases")
        .orderBy("createdAt", "desc");

      if (status && typeof status === "string") {
        query = query.where("status", "==", status);
      }

      const snap = await query.limit(l).get();

      const cases: VisaCase[] = snap.docs.map((d) => {
        const c = d.data() as any;
        return {
          id: d.id,
          ...c,
          createdAt: c.createdAt?.toDate?.() ?? new Date(),
          updatedAt: c.updatedAt?.toDate?.() ?? new Date(),
          submittedAt: c.submittedAt?.toDate?.() ?? null,
          decidedAt: c.decidedAt?.toDate?.() ?? null,
        };
      });

      (res as any).json(cases);
    } catch (err) {
      console.error("List cases error", err);
      (res as any).status(500).json({ error: "Server error" });
    }
  }
);

router.patch(
  "/:id/status",
  authMiddleware,
  requireRoles("ADMIN", "AGENT", "SUPER_ADMIN"),
  async (req: Request, res: Response) => {
    try {
      const parse = updateStatusSchema.safeParse((req as any).body);
      if (!parse.success) {
        (res as any).status(400).json({ error: "Invalid body" });
        return;
      }

      const { id } = (req as any).params;
      const { status } = parse.data;
      if (!allowedStatuses.includes(status as CaseStatus)) {
        (res as any).status(400).json({ error: "Invalid status" });
        return;
      }

      const caseRef = db.collection("cases").doc(id);
      const snap = await caseRef.get();
      if (!snap.exists) {
        (res as any).status(404).json({ error: "Case not found" });
        return;
      }

      const now = new Date();
      await caseRef.update({
        status,
        updatedAt: now,
      });

      (res as any).json({ id, status });
    } catch (err) {
      console.error("Update case status error", err);
      (res as any).status(500).json({ error: "Server error" });
    }
  }
);

export default router;
