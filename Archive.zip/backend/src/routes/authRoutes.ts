import { Router } from "express";
import { db } from "../config/firebase";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { User, UserRole } from "../types/models";
import { z } from "zod";

const router = Router();

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(4),
});

router.post("/login", async (req, res) => {
  try {
    const parse = loginSchema.safeParse(req.body);
    if (!parse.success) {
      return res.status(400).json({ error: "Invalid body" });
    }
    const { email, password } = parse.data;

    const snap = await db
      .collection("users")
      .where("email", "==", email)
      .limit(1)
      .get();

    if (snap.empty) {
      return res.status(401).json({ error: "Invalid credentials" });
    }

    const doc = snap.docs[0];
    const u = doc.data() as any;
    if (!u.active) {
      return res.status(403).json({ error: "User inactive" });
    }

    const ok = await bcrypt.compare(password, u.passwordHash);
    if (!ok) return res.status(401).json({ error: "Invalid credentials" });

    const secret = process.env.JWT_SECRET || "default_dev_secret";

    const token = jwt.sign(
      { id: doc.id, role: u.role as UserRole, partnerId: u.partnerId || null },
      secret,
      { expiresIn: "12h" }
    );

    const user: Partial<User> = {
      id: doc.id,
      email: u.email,
      role: u.role,
      active: u.active,
      partnerId: u.partnerId || null,
    };

    res.json({ token, user });
  } catch (err: any) {
    console.error("Login error", err);
    res.status(500).json({ error: "Server error" });
  }
});

export default router;