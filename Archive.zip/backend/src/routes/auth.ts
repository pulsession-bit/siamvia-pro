import { Request, Response, NextFunction } from "express";
import jwt from "jsonwebtoken";
import { UserRole } from "../types/models";

// Define AuthRequest as an interface extending Express Request
export interface AuthRequest extends Request {
  user?: {
    id: string;
    role: UserRole;
    partnerId?: string | null;
  };
}

export function authMiddleware(
  req: Request,
  res: Response,
  next: NextFunction
) {
  const header = (req as any).headers?.authorization;
  if (!header || !header.startsWith("Bearer ")) {
    (res as any).status(401).json({ error: "Unauthorized" });
    return;
  }

  const token = header.substring("Bearer ".length);
  try {
    const secret = process.env.JWT_SECRET || "default_dev_secret";
    const payload = jwt.verify(token, secret) as any;
    (req as AuthRequest).user = {
      id: payload.id,
      role: payload.role,
      partnerId: payload.partnerId,
    };
    next();
  } catch (err) {
    (res as any).status(401).json({ error: "Invalid token" });
    return;
  }
}

export function requireRoles(...roles: UserRole[]) {
  return (req: Request, res: Response, next: NextFunction) => {
    const authReq = req as AuthRequest;
    
    if (!authReq.user) {
        (res as any).status(401).json({ error: "Unauthorized" });
        return;
    }
    if (!roles.includes(authReq.user.role)) {
      (res as any).status(403).json({ error: "Forbidden" });
      return;
    }
    next();
  };
}