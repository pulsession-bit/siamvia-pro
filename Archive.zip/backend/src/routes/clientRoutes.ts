import { Router, Request, Response } from "express";
import { db } from "../config/firebase";
import { AuthRequest, authMiddleware, requireRoles } from "../middleware/auth";
import { Client } from "../types/models";
import { z } from "zod";

const router = Router();

const clientSchema = z.object({
  firstName: z.string(),
  lastName: z.string(),
  email: z.string().email(),
  dateOfBirth: z.string().optional(),
  nationality: z.string().optional(),
  phone: z.string().optional(),
  countryOfResidence: z.string().optional(),
  preferredLanguage: z.string().optional(),
  leadSource: z.string().optional(),
  tags: z.array(z.string()).optional(),
});

// Création d'un client
router.post(
  "/",
  authMiddleware,
  requireRoles("ADMIN", "AGENT", "SUPER_ADMIN", "PARTNER"),
  async (req: Request, res: Response) => {
    try {
      const parse = clientSchema.safeParse((req as any).body);
      if (!parse.success) {
        (res as any).status(400).json({ error: "Invalid body" });
        return;
      }
      const data = parse.data;
      const now = new Date();

      const docRef = await db.collection("clients").add({
        ...data,
        createdAt: now,
        updatedAt: now,
      });

      const client: Client = {
        id: docRef.id,
        ...data,
        createdAt: now,
        updatedAt: now,
      } as any;

      (res as any).status(201).json(client);
    } catch (err) {
      console.error("Create client error", err);
      (res as any).status(500).json({ error: "Server error" });
    }
  }
);

// Listing des clients
router.get(
  "/",
  authMiddleware,
  requireRoles("ADMIN", "AGENT", "SUPER_ADMIN", "ACCOUNTING", "PARTNER"),
  async (req: Request, res: Response) => {
    try {
      const { limit = "50" } = (req as any).query;
      const l = Math.min(parseInt(limit as string, 10) || 50, 200);

      const snap = await db
        .collection("clients")
        .orderBy("createdAt", "desc")
        .limit(l)
        .get();

      const clients: Client[] = snap.docs.map((d) => {
        const c = d.data() as any;
        return {
          id: d.id,
          ...c,
          createdAt: c.createdAt?.toDate?.() ?? new Date(),
          updatedAt: c.updatedAt?.toDate?.() ?? new Date(),
        };
      });

      (res as any).json(clients);
    } catch (err) {
      console.error("List clients error", err);
      (res as any).status(500).json({ error: "Server error" });
    }
  }
);

export default router;