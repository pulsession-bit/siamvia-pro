import { Router, Request, Response } from "express";
import { db } from "../config/firebase";
import { authMiddleware, requireRoles } from "../middleware/auth";

const router = Router();

router.get(
  "/overview",
  authMiddleware,
  requireRoles("ADMIN", "SUPER_ADMIN", "ACCOUNTING"),
  async (req: Request, res: Response) => {
    try {
      const casesSnap = await db.collection("cases").get();
      const byStatus: Record<string, number> = {};
      casesSnap.forEach((doc) => {
        const data = doc.data() as any;
        const s = data.status || "UNKNOWN";
        byStatus[s] = (byStatus[s] || 0) + 1;
      });

      const paymentsSnap = await db
        .collection("payments")
        .where("status", "==", "SUCCEEDED")
        .get();
      let totalAmount = 0;
      const currencyCounter: Record<string, number> = {};
      paymentsSnap.forEach((doc) => {
        const p = doc.data() as any;
        totalAmount += p.amount || 0;
        const cur = p.currency || "unknown";
        currencyCounter[cur] = (currencyCounter[cur] || 0) + p.amount;
      });

      (res as any).json({
        totalCases: casesSnap.size,
        casesByStatus: byStatus,
        totalPaymentsSucceeded: paymentsSnap.size,
        totalAmount,
        amountByCurrency: currencyCounter,
      });
    } catch (err) {
      console.error("Stats error", err);
      (res as any).status(500).json({ error: "Server error" });
    }
  }
);

export default router;