import { db } from "../config/firebase";
import { MailLogEntry } from "../types/models";

export async function logMail(entry: Omit<MailLogEntry, "id" | "createdAt">) {
  const now = new Date();

  try {
    const docRef = await db.collection("mailLogs").add({
      ...entry,
      createdAt: now,
    });
    return { id: docRef.id, createdAt: now };
  } catch (error) {
    console.error("Failed to write mail log to Firestore:", error);
    return null;
  }
}