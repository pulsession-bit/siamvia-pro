export type UserRole =
  | "SUPER_ADMIN"
  | "ADMIN"
  | "AGENT"
  | "ACCOUNTING"
  | "PARTNER";

export interface User {
  id: string;
  email: string;
  passwordHash: string;
  role: UserRole;
  active: boolean;
  createdAt: Date;
  partnerId?: string | null;
}

export interface Client {
  id: string;
  firstName: string;
  lastName: string;
  dateOfBirth?: string;
  nationality?: string;
  email: string;
  phone?: string;
  countryOfResidence?: string;
  preferredLanguage?: string;
  leadSource?: string;
  tags?: string[];
  createdAt: Date;
  updatedAt: Date;
}

export type CaseStatus =
  | "LEAD_CREATED"
  | "PRECHECK_IN_PROGRESS"
  | "ELIGIBLE"
  | "NOT_ELIGIBLE"
  | "WAITING_PAYMENT"
  | "PAYMENT_CONFIRMED"
  | "DOCUMENTS_IN_PROGRESS"
  | "CASE_COMPLETE"
  | "SUBMITTED_TO_AUTHORITY"
  | "PENDING_DECISION"
  | "APPROVED"
  | "REFUSED"
  | "CANCELLED_CLIENT"
  | "ABANDONED";

export interface VisaCase {
  id: string;
  reference: string;
  clientId: string;
  visaType: string; // "DTV" etc.
  status: CaseStatus;
  assignedAgentId?: string | null;
  officialReference?: string | null;
  createdAt: Date;
  updatedAt: Date;
  submittedAt?: Date | null;
  decidedAt?: Date | null;
}

export type PaymentStatus = "PENDING" | "SUCCEEDED" | "FAILED" | "REFUNDED";

export interface Payment {
  id: string;
  caseId: string;
  amount: number;
  currency: string;
  provider: "STRIPE";
  stripeSessionId?: string;
  stripePaymentIntentId?: string;
  status: PaymentStatus;
  createdAt: Date;
  confirmedAt?: Date | null;
  refundedAt?: Date | null;
}

export type MailStatus = "SENT" | "FAILED";

export interface MailLogEntry {
  id?: string;
  createdAt: Date;
  type: string;      // "INTAKE", "APPOINTMENT", "CASE_UPDATE", etc.
  to: string;
  from: string;
  subject: string;
  status: MailStatus;
  errorMessage?: string;
  meta?: any;        // JSON metadata
}