import dotenv from "dotenv";
import path from "path";

// Charger les variables d'environnement
dotenv.config({ path: path.resolve(".env") });

// Import après la config pour garantir que Firebase s'initialise
import { db } from "../config/firebase";
import bcrypt from "bcryptjs";
import { UserRole } from "../types/models";
import admin from "firebase-admin";

async function createAdmin() {
  const email = "admin@siamvisapro.com";
  const password = "admin"; 
  const role: UserRole = "SUPER_ADMIN";

  console.log("--- STARTING ADMIN CREATION SCRIPT ---");
  
  // Vérification de sécurité simple
  const apps = admin.apps;
  if (!apps.length || apps[0]?.options.projectId === 'demo-project') {
     console.warn("⚠️ WARNING: Firebase semble être en mode Mock ou non connecté.");
     console.warn("Vérifiez que 'service-account.json' est bien dans le dossier backend/");
  } else {
     console.log(`Target Project ID: ${apps[0]?.options.projectId}`);
  }

  try {
    console.log(`Checking if user ${email} exists in Firestore...`);
    const snap = await db.collection("users").where("email", "==", email).get();

    const passwordHash = await bcrypt.hash(password, 10);

    if (!snap.empty) {
      console.log("User already exists. Updating password...");
      const doc = snap.docs[0];
      await doc.ref.update({ 
        passwordHash, 
        role, 
        active: true,
        updatedAt: new Date()
      });
      console.log("✅ User updated successfully.");
    } else {
      console.log("User not found. Creating new SUPER_ADMIN user...");
      
      const newUser = {
        email,
        passwordHash,
        role,
        active: true,
        createdAt: new Date(),
        partnerId: null
      };

      await db.collection("users").add(newUser);
      console.log("✅ User created successfully.");
    }
    
    console.log("-----------------------------------------");
    console.log(`LOGIN: ${email}`);
    console.log(`PASS:  ${password}`);
    console.log("-----------------------------------------");

    (process as any).exit(0);
  } catch (error) {
    console.error("❌ Error creating admin:", error);
    (process as any).exit(1);
  }
}

createAdmin();