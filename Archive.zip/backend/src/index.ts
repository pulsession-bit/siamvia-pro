import express from "express";
import cors from "cors";
import dotenv from "dotenv";

dotenv.config();

import authRoutes from "./routes/authRoutes";
import clientRoutes from "./routes/clientRoutes";
import caseRoutes from "./routes/caseRoutes";
import paymentRoutes from "./routes/paymentRoutes";
import statsRoutes from "./routes/statsRoutes";
import mailLogRoutes from "./routes/mailLogRoutes";

const app = express();

// Middleware : Stripe Webhook doit recevoir le corps "raw" (brut), pas du JSON parsé
app.use((req, res, next) => {
  if (req.originalUrl.startsWith('/payments/webhook')) {
    next();
  } else {
    // Cast req/res to any to bypass type mismatch between express Request and http IncomingMessage expected by express.json()
    express.json()(req as any, res as any, next);
  }
});

app.use(
  cors({
    origin: process.env.CORS_ORIGIN
      ? process.env.CORS_ORIGIN.split(",")
      : "*",
  })
);

app.get("/health", (_req, res) => {
  res.json({ status: "ok", timestamp: new Date() });
});

app.use("/auth", authRoutes);
app.use("/clients", clientRoutes);
app.use("/cases", caseRoutes);
app.use("/payments", paymentRoutes);
app.use("/stats", statsRoutes);
app.use("/mail-logs", mailLogRoutes);

const PORT = process.env.PORT || 8080;
app.listen(PORT, () => {
  console.log(`✅ SiamVisa Pro Backend running on port ${PORT}`);
});